# Sample webserver for Spinnaker codelab

Source to prod Kubernetes Spinnaker artifact code is staged here. The point is
to provide a simple webserver that can have its colors/content quickly tweaked
during a demo or tutorial.
