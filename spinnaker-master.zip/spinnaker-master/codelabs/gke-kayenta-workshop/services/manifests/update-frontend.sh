#!/usr/bin/env bash

gsutil cp frontend.yml {%BUCKET_URI%}/manifests/frontend.yml
