#!/usr/bin/env bash

gsutil cp backend.yml {%BUCKET_URI%}/manifests/backend.yml
