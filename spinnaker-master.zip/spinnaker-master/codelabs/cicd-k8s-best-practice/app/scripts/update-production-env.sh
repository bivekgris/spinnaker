#!/usr/bin/env bash

gsutil cp manifests/production/env.yaml gs://spinnaker-playground/manifests/demo/production/env.yaml
