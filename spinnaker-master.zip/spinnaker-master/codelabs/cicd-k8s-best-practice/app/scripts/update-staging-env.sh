#!/usr/bin/env bash

gsutil cp manifests/staging/env.yaml gs://spinnaker-playground/manifests/demo/staging/env.yaml
